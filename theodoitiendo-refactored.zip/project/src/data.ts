import { TaskA, TaskBC, TaskD } from './types';

export const SEED_A: TaskA[] = [
  {
    id: "A1",
    stt: 1,
    content: "Kết quả công tác xây dựng, chỉnh đốn Đảng; củng cố, xây dựng tổ chức đảng và hệ thống chính trị; nâng cao chất lượng đội ngũ cán bộ, đảng viên theo nghị quyết, kế hoạch, chỉ tiêu được giao",
    maxPoints: 5,
    unit: "",
    status: ""
  },
  {
    id: "A2",
    stt: 2,
    content: "Năng lực lãnh đạo của cấp ủy; hiệu quả lãnh đạo, chỉ đạo của cấp ủy đối với đơn vị, các cấp ủy, tổ chức đảng cấp dưới trong CAND theo thẩm quyền; hiệu quả trong phối hợp công tác; xây dựng đoàn kết nội bộ",
    maxPoints: 5,
    unit: "",
    status: ""
  },
  {
    id: "A3",
    stt: 3,
    content: "Hiệu quả trong công tác thanh tra, kiểm tra, giám sát và kỷ luật đảng; thực hiện các quy định về kiểm soát quyền lực; không để xảy ra tham nhũng, lãng phí, tiêu cực, suy thoái về tư tưởng chính trị, đạo đức, lối sống, 'tự diễn biến', 'tự chuyển hóa' trong nội bộ.",
    maxPoints: 5,
    unit: "",
    status: ""
  },
  {
    id: "A4",
    stt: 4,
    content: "Kết quả thực hiện các nguyên tắc tổ chức và hoạt động của đảng, nhất là nguyên tắc tập trung dân chủ, tự phê bình và phê bình; việc chấp hành quy chế làm việc, nội quy, chế độ công tác; phân công nhiệm vụ, tổ chức thực hiện hiệu quả.",
    maxPoints: 5,
    unit: "",
    status: ""
  },
  {
    id: "A5",
    stt: 5,
    content: "Kết quả lãnh đạo, chỉ đạo, kiểm tra, giám sát việc thực hiện nhiệm vụ chính trị; xây dựng bộ máy tinh gọn, tinh giản biên chế, hoạt động hiệu năng, hiệu lực, hiệu quả; thực hiện cải cách hành chính, chuyển đổi số, đẩy mạnh ứng dụng khoa học, công nghệ, phương pháp quản lý gắn với xây dựng văn hóa công vụ trong hoạt động quản lý, điều hành đơn vị.",
    maxPoints: 5,
    unit: "",
    status: ""
  },
  {
    id: "A6",
    stt: 6,
    content: "Tinh thần tự phê bình và phê bình, tự soi, tự sửa của tập thể đơn vị; kết quả khắc phục những hạn chế, yếu kém, khuyết điểm đã được chỉ ra trong các kỳ kiểm điểm trước hoặc qua thanh tra, kiểm tra, giám sát.",
    maxPoints: 5,
    unit: "",
    status: ""
  }
];

export const SEED_B: TaskBC[] = [
  {
    id: "B1",
    stt: 1,
    canCu: "Công văn số 4524/CAT-PV01(XDPT) ngày 25/6/2026 của Công an tỉnh về triển khai thực hiện Quyết định và Kế hoạch của Bộ Công an về xây dựng Công an xã, phường, đặc khu kiểu mẫu về ANTT",
    noiDung: "Chấm điểm thực hiện tiêu chí xây dựng Công an xã, phường, đặc khu kiểu mẫu về ANTT, Báo trước ngày 29/6",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "Đ8-PV01",
    sanPham: "Bảng tự chấm điểm",
    ngayHetHan: "2026-06-29",
    trangThai: ""
  },
  {
    id: "B2",
    stt: 2,
    canCu: "Kế hoạch số 330/KH-CAT-PV01(Đ8) ngày 12/6/2026 Công an tỉnh đã ban hành về tổ sơ kết 05 năm thực hiện Thông tư số 124/2021/TT-BCA ngày 28/12/2021 của Bộ Công an quy định khu dân cư, xã, phường, thị trấn, cơ quan, doanh nghiệp, cơ sở giáo dục đạt tiêu chuẩn “An toàn về an ninh, trật tự” giai đoạn 2021-2026.",
    noiDung: "Công an cấp xã Báo cáo kết quả về Công an tinh trước ngày 10/7",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "Đ8-PV01",
    sanPham: "Báo cáo",
    ngayHetHan: "2026-07-10",
    trangThai: ""
  },
  {
    id: "B3",
    stt: 3,
    canCu: "Công văn số 850/CAT-PC06 về việc tăng cường kiểm tra công tác lưu trú, tập trung vào các đối tượng thuộc diện quản lý liên quan đến ma túy",
    noiDung: "Giao Công an các địa phương thực hiện kiểm tra 100% các cơ sở có liên quan đến ma túy, hoàn thành trước ngày 15/7/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC06",
    sanPham: "Có báo cáo kết quả kiểm tra cuối đợt",
    ngayHetHan: "2026-07-15",
    trangThai: ""
  },
  {
    id: "B4",
    stt: 4,
    canCu: "Kế hoạch số 292/KH-CAT-PC06 ngày 28/5/2026 về việc triển khai “Chiến dịch mùa hè số cùng VNeID”",
    noiDung: "Thực hiện đảm bảo các yêu cầu, nội dung của kế hoạch; kết quả bước đầu hoàn thành trước ngày 30/6/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC06",
    sanPham: "Đồng loạt tổ chức Lễ ra quân theo kế hoạch của CA tỉnh; có báo cáo",
    ngayHetHan: "2026-06-30",
    trangThai: ""
  },
  {
    id: "B5",
    stt: 5,
    canCu: "Kế hoạch số 38/KH-CAT-PC07 ngày 21/01/2026 của Công an tỉnh về việc triển khai công tác quản lý, vận hành, khai thác, sử dụng và tiếp tục cập nhật, hoàn thiện Cơ sở dữ liệu quốc gia về PCCC và CNCH, truyền tin báo cháy và ứng dụng \"Báo cháy 114\"",
    noiDung: "Hướng dẫn cơ sở thuộc diện quản lý về PCCC và CNCH trang bị, kết nối thiết bị truyền tin báo cháy",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC07",
    sanPham: "",
    ngayHetHan: "2026-07-20",
    trangThai: ""
  },
  {
    id: "B6",
    stt: 6,
    canCu: "Kế hoạch số 03/KH-CAT-PC07 ngày 07/01/2026 của Công an tỉnh",
    noiDung: "Không để xảy ra vụ cháy cấp V; Không để xảy ra vụ cháy cấp III trở lên so với năm 2025",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC07",
    sanPham: "",
    ngayHetHan: "2026-07-31",
    trangThai: ""
  },
  {
    id: "B7",
    stt: 7,
    canCu: "",
    noiDung: "Tham mưu UBND cùng cấp thực hiện kiểm tra an toàn PCCC đối với các cơ sở quy định tại Điểm c, Khoản 2, Điều 13 Nghị định số 105/2025/NĐ-CP",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC07",
    sanPham: "",
    ngayHetHan: "2026-07-25",
    trangThai: ""
  },
  {
    id: "B8",
    stt: 8,
    canCu: "Quyết định số 16-QĐ/UBKT, ngày 22/4/2026 của UBKT Đảng ủy Công an tỉnh về ban hành khung tiêu chí đánh giá, chấm điểm thi đua trên lĩnh vực công tác kiểm tra, giám sát, thi hành kỷ luật của Đảng trong Công an Lâm Đồng năm 2026",
    noiDung: "Có thông báo để UBKT cấp trên dự các hội nghị, cuộc họp của cấp ủy, chi bộ; cử thành viên UBKT cấp mình dự các cuộc họp với cấp ủy, tổ chức đảng cấp dưới",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX06",
    sanPham: "",
    ngayHetHan: "2026-07-12",
    trangThai: ""
  },
  {
    id: "B9",
    stt: 9,
    canCu: "Công văn số 997/CAT-PX03 ngày 23/6/2026 về rà soát, lập danh sách trang thông tin điện tử cá nhân của CBCS theo Quy định số 85-QĐ/TW",
    noiDung: "Lập danh sách trang thông tin điện tử cá nhân của CBCS theo Quy định số 85-QĐ/TW trước 26/6/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX03 (Đội 1)",
    sanPham: "Báo cáo danh sách trang thông tin điện tử của CBCS",
    ngayHetHan: "2026-06-26",
    trangThai: ""
  },
  {
    id: "B10",
    stt: 10,
    canCu: "Kế hoạch số 347/KH-CAT-PX03 ngày 19/6/2026 về triển khai Phong trào thi đua \"Đẩy mạnh cải cách hành chính Nhà nước trên địa bàn tỉnh Lâm Đồng giai đoạn 2026-2030\"",
    noiDung: "Triển khai Phong trào thi đua \"Đẩy mạnh cải cách hành chính Nhà nước trên địa bàn tỉnh Lâm Đồng giai đoạn 2026-2030\" trước 30/6/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX03 (Đội 2)",
    sanPham: "Kế hoạch triển khai của đơn vị",
    ngayHetHan: "2026-06-30",
    trangThai: ""
  },
  {
    id: "B11",
    stt: 11,
    canCu: "Công văn số 4636/CAT-PX03 ngày 29/6/2026 của CAT về Sơ kết 6 tháng đầu năm 2026 về thực hiện phong trào thi đua \"Ba nhất: Kỷ luật nhất- Trung thành nhất- Gần dân nhất\" của Bộ Công an",
    noiDung: "Sơ kết 6 tháng đầu năm 2026 về thực hiện phong trào thi đua \"Ba nhất: Kỷ luật nhất- Trung thành nhất- Gần dân nhất\" của Bộ Công an trước 2/7/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX03 (Đội 2)",
    sanPham: "Báo cáo kết quả",
    ngayHetHan: "2026-07-02",
    trangThai: ""
  },
  {
    id: "B12",
    stt: 12,
    canCu: "Kế hoạch số 360/KH-CAT-PX03 ngày 24/6/2026 về Tổ chức CBCS tham quan Triển lãm hiện vật, hình ảnh lịch sử chào mừng kỷ niệm 80 năm Ngày truyền thống CAND; báo cáo số lượng CBCS tham quan",
    noiDung: "Tổ chức CBCS tham quan Triển lãm hiện vật, hình ảnh lịch sử chào mừng kỷ niệm 80 năm Ngày truyền thống CAND; báo cáo số lượng CBCS tham quan trước 10/7/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX03 (Đội 3)",
    sanPham: "Báo cáo số lượng CBCS tham quan",
    ngayHetHan: "2026-07-10",
    trangThai: ""
  },
  {
    id: "B13",
    stt: 13,
    canCu: "Kế hoạch số 314/KH-CAT-PX03 ngày 05/6/2026 về Triển khai Cuộc thi Đại sứ Văn hóa đọc năm 2026",
    noiDung: "Triển khai Cuộc thi Đại sứ Văn hóa đọc năm 2026 trước 10/7/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX03 (Đội 3)",
    sanPham: "Báo cáo kết quả tổ chức và bài dự thi",
    ngayHetHan: "2026-07-10",
    trangThai: ""
  },
  {
    id: "B14",
    stt: 14,
    canCu: "Công văn số 2242/CAT-PX03 ngày 16/4/2026 về Triển khai Cuộc thi Đại sứ Văn hóa đọc năm 2026",
    noiDung: "Triển khai Cuộc thi với chủ đề \"50 năm Tự hào lực lượng Cảnh sát PCCC\" trước 5/7/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX03 (Đội 3)",
    sanPham: "Báo cáo kết quả triển khai",
    ngayHetHan: "2026-07-05",
    trangThai: ""
  },
  {
    id: "B15",
    stt: 15,
    canCu: "Kế hoạch số 08/KH-CAT-PV01 ngày 08/7/2025 về Tổ chức đợt sinh hoạt chính trị kỷ niệm 80 năm Ngày truyền thống lực lượng An ninh nhân dân",
    noiDung: "Tổ chức đợt sinh hoạt chính trị kỷ niệm 80 năm Ngày truyền thống lực lượng An ninh nhân dân trước 10/7/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX03 (BTN)",
    sanPham: "Ít nhất 01 hoạt động tại đơn vị",
    ngayHetHan: "2026-07-10",
    trangThai: ""
  },
  {
    id: "B16",
    stt: 16,
    canCu: "Kế hoạch số 256/KH-BAN(PX03) ngày 12/5/2026 của Ban vì sự tiến bộ phụ nữ, công tác gia đình và trẻ em Công an tỉnh",
    noiDung: "Báo cáo kết quả triển khai tháng hành động quốc gia về phòng chống bạo lực gia đình, tháng hành động vì trẻ em năm 2026 và tổ chức các hoạt động kỷ niệm 25 năm ngày gia đình Việt Nam trước 25/6/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX03 (HPN)",
    sanPham: "Báo cáo kết quả triển khai",
    ngayHetHan: "2026-06-25",
    trangThai: ""
  },
  {
    id: "B17",
    stt: 17,
    canCu: "Công văn số 702/PX05-Đ2 ngày 17/6/2026 của Thanh tra Công an tỉnh về việc báo cáo phục vụ thanh tra việc chấp hành các quy định của pháp luật về phòng, chống tham nhũng",
    noiDung: "Đề nghị gửi báo cáo trước ngày 30/6/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX05",
    sanPham: "Báo cáo của Công an các đơn vị, địa phương",
    ngayHetHan: "2026-06-30",
    trangThai: ""
  },
  {
    id: "B18",
    stt: 18,
    canCu: "Kết luận thanh tra số 693/KL-PX05 ngày 15/6/2026 về thanh tra chuyên đề cơ sở nhà đất dôi dư sau sắp xếp của cơ quan tổ chức thuộc thẩm quyền quản lý của Công an tỉnh Lâm Đồng",
    noiDung: "Đề nghị báo cáo quả thực hiện Kết luận thanh tra trước ngày 10/7/2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX05",
    sanPham: "Báo cáo kết quả thực hiện Kết luận thanh tra",
    ngayHetHan: "2026-07-10",
    trangThai: ""
  },
  {
    id: "B19",
    stt: 19,
    canCu: "Kế hoạch số 233/KH-CAT-PA02 ngày 16/6/2026 về đấu tranh, xử lý số đối tượng lợi dụng khiếu kiện vi phạm pháp luật",
    noiDung: "Các xã, phường, đặc khu xây dựng kế hoạch đấu tranh, xử lý số đối tượng lợi dụng khiếu kiện vi phạm pháp luật và lập danh sách số đầu đơn, cốt cán khiếu kiện trên địa bàn",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA02 (Đội 3)",
    sanPham: "Xây dựng kế hoạch và lập danh sách đầu đơn khiếu kiện gửi trước ngày 30/6/2026",
    ngayHetHan: "2026-06-30",
    trangThai: ""
  },
  {
    id: "B20",
    stt: 20,
    canCu: "Công văn số 4380/CAT-PH10 ngày 23/6/2026 gửi CA các đơn vị, địa phương về việc hướng dẫn tổ chức các hoạt động hưởng ứng Ngày Thế giới chống sa mạc hóa và hạn hán năm 2026",
    noiDung: "báo cáo kết quả triển khai thực hiện các hoạt động hưởng ứng",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PH10, PV01",
    sanPham: "báo cáo gửi CAT (qua PH10) trước 25/6",
    ngayHetHan: "2026-06-25",
    trangThai: ""
  },
  {
    id: "B21",
    stt: 21,
    canCu: "Công văn số 3724/CAT-PH10 ngày 04/6/2026 triển khai Công văn số 5087/BNNMT-VP ngày 21/5/2026 của Bộ Nông nghiệp và Môi trường; Công văn số 7537/UBND-NNMT ngày 22/5/2026 của Ủy ban nhân dân tỉnh Lâm Đồng; Công văn số 8017/UBND-NNMT ngày 30/5/2026 của Ủy ban nhân dân tỉnh Lâm Đồng; Công văn số 7041/SNNMT-MT ngày 29/5/2026 của Sở Nông nghiệp và Môi trường tỉnh Lâm Đồng về việc tổ chức các hoạt động hưởng ứng Ngày Môi trường Thế giới, Tháng hành động vì môi trường và Ngày Đại dương thế giới, Tuần lễ Biển và Hải đảo Việt Nam năm 2026",
    noiDung: "Triển khai thực hiện việc tổ chức các hoạt động hưởng ứng Ngày Môi trường Thế giới, Tháng hành động vì môi trường và Ngày Đại dương thế giới, Tuần lễ Biển và Hải đảo Việt Nam năm 2026 trong Công an tỉnh Lâm Đồng",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PV01, PH10",
    sanPham: "báo cáo về Công an tỉnh trước ngày 01/7/2026",
    ngayHetHan: "2026-07-01",
    trangThai: ""
  },
  {
    id: "B22",
    stt: 22,
    canCu: "Kế hoạch số 40/KH-CAT-PH10 ngày 21/01/2026 về triển khai Kế hoạch số 209/KH-UBND ngày 07/01/2026 của UBND tỉnh về triển khai Tháng hành động về An toàn, vệ sinh lao động, Tháng công nhân năm 2026 trên địa bàn tỉnh Lâm Đồng",
    noiDung: "Báo cáo kết quả triển khai tháng hành động vệ sinh an toàn lao động năm 2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PV01, PH10",
    sanPham: "Báo cáo về Công an tỉnh trước ngày 01/7/2026",
    ngayHetHan: "2026-07-01",
    trangThai: ""
  },
  {
    id: "B23",
    stt: 23,
    canCu: "Công văn số 474/CV-CAT-PA06 ngày 10/12/2025 của Công an tỉnh về việc thu thập thông tin Camera giám sát phục vụ công tác Công an",
    noiDung: "Thực hiện định kỳ hằng tháng, 06 tháng, năm báo cáo kết quả thu thập thông tin theo biểu mẫu số 01 và 02 nộp về Công an tỉnh (qua PA06)",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA06",
    sanPham: "Định kỳ 06 tháng, năm báo cáo",
    ngayHetHan: "2026-06-30",
    trangThai: ""
  },
  {
    id: "B24",
    stt: 24,
    canCu: "Công văn số 952/CAT-PV06 ngày 09/06/2026 của Công an tỉnh về khẩn trương khắc phục và xử lý dứt điểm tồn tại hạn chế trong công tác hồ sơ nghiệp vụ trên các phần mềm NVCB, ĐTHS, HSNV",
    noiDung: "Xử lý dứt điểm tồn tại, hạn chế trong công tác hồ sơ nghiệp vụ trên các phần mềm NVCB, ĐTHS, HSNV",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PV06",
    sanPham: "Khắc phục dứt điểm tình trạng chênh lệch số liệu thống kế hồ sơ nghiệp vụ CS đang quản lý, sử dụng giữa Công an các đơn vị, địa phương với PV06",
    ngayHetHan: "2026-07-15",
    trangThai: ""
  },
  {
    id: "B25",
    stt: 25,
    canCu: "Công văn số 1010/CAT-PV06 - Đ1 ngày 26/06/2026 về chấn chỉnh trong thực hiện công tác hồ sơ NVCB của lực lượng CSND",
    noiDung: "Chấn chỉnh trong thực hiện công tác hồ sơ nghiệp vụ cơ bản của lực lượng CSND",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PV06",
    sanPham: "Kết thúc nộp lưu hồ sơ NVCB quá hạn",
    ngayHetHan: "2026-07-20",
    trangThai: ""
  }
];

export const SEED_C: TaskBC[] = [
  {
    id: "C1",
    stt: 1,
    canCu: "Nghị quyết số 12-NQ/ĐUCA ngày 24/4/2026 của Đảng ủy Công an tỉnh và Chương trình hành động số 560/CTr-CAT-PV01(XDPT) ngày 24/4/2026 của Công an tỉnh về xây dựng Công an xã, phường, đặc khu vững mạnh, hiện đại, bám cơ sở đáp ứng yêu cầu, nhiệm vụ trong tình hình mới trong Công an tỉnh Lâm Đồng.",
    noiDung: "Báo cáo kết quả thực hiện trước ngày 17 hằng tháng",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "Đ8-PV01",
    sanPham: "Báo cáo",
    ngayHetHan: "2026-07-17",
    trangThai: ""
  },
  {
    id: "C2",
    stt: 2,
    canCu: "Kế hoạch số 58/KH-CAT-PA04 ngày 02/02/2026 của Giám đốc Công an tỉnh về kiểm tra việc chấp hành quy định pháp luật thuộc phạm vi quản lý nhà nước của Công an tỉnh Lâm Đồng tại các doanh nghiệp, hộ kinh doanh, cá nhân kinh doanh trong năm 2026",
    noiDung: "Báo cáo kết quả kiểm tra doanh nghiệp, hộ kinh doanh, cá nhân kinh doanh của Công an các địa phương",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA04",
    sanPham: "Báo cáo định kỳ hằng tháng",
    ngayHetHan: "2026-07-25",
    trangThai: ""
  },
  {
    id: "C3",
    stt: 3,
    canCu: "Kế hoạch số 159/KH-CAT-PA04 ngày 25/9/2025 của Công an tỉnh về \"Nâng cao hiệu quả công tác đấu tranh phòng, chống rửa tiền, tài trợ khủng bố và tài trợ vũ khí hủy diệt hàng loạt\"",
    noiDung: "Kết quả triển khai các nhiệm vụ phòng chống rửa tiền và tài trợ khủng bố",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA04",
    sanPham: "Báo cáo định kỳ hằng tháng",
    ngayHetHan: "2026-07-28",
    trangThai: ""
  },
  {
    id: "C4",
    stt: 4,
    canCu: "Báo cáo kết quả thực hiện nhiệm vụ theo Quyết định 6434/QĐ-CAT ngày 25/11/2025 của Giám đốc Công an tỉnh về thành lập Ban Chỉ đạo các công trình, dự án trọng điểm của tỉnh",
    noiDung: "Kết quả triển khai các nhiệm vụ bảo đảm ANTT dự án, công trình trọng điểm",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA04",
    sanPham: "Báo cáo định kỳ hằng tháng",
    ngayHetHan: "2026-07-20",
    trangThai: ""
  },
  {
    id: "C5",
    stt: 5,
    canCu: "Kế hoạch số 196/KH-CAT-PA04 ngày 20/5/2026 về công tác công an bảo đảm ANTT quá trình triển khai thực hiện dự án \"Nhà máy điện phân nhôm Đắk Nông\"",
    noiDung: "Báo cáo kết quả triển khai các biện pháp bảo đảm ANTT tại dự án nhà máy điện phân nhôm Đắk Nông",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA04",
    sanPham: "Báo cáo",
    ngayHetHan: "2026-07-15",
    trangThai: ""
  },
  {
    id: "C6",
    stt: 6,
    canCu: "Thực hiện các nhiệm vụ theo Công văn số 834/CAT-PA04 ngày 04/6/2026 về việc nắm tình hình công tác quản lý xuất, nhập khẩu hàng hóa tại khu vực biên giới",
    noiDung: "- Tổ chức Rà soát, nắm tình hình về công tác quản lý xuất, nhập khẩu hàng hóa tại cửa khẩu biên giới, đường mòn, lối mở\n- Phát hiện, xử lý vi phạm\n- công tác tham mưu, phối hợp",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA04",
    sanPham: "Báo cáo định kỳ hằng tháng",
    ngayHetHan: "2026-07-10",
    trangThai: ""
  },
  {
    id: "C7",
    stt: 7,
    canCu: "CV 839/CAT-PA04 ngày 5/6/2026 thực hiện chỉ đạo của Cục A04-BCA triển khai Nghị quyết số 29/2026/QH16 của Quốc Hội và Nghị định số 147/2026/NĐCP của Chính phủ",
    noiDung: "Cập nhật số liệu các nội dung trước ngày 10 hàng tháng, trao đổi bằng văn bản để phục vụ báo cáo định kỳ.",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA04",
    sanPham: "Báo cáo định kỳ hằng tháng",
    ngayHetHan: "2026-07-10",
    trangThai: ""
  },
  {
    id: "C8",
    stt: 8,
    canCu: "Đề án số 14/ĐA-BCA-A03 ngày 23/11/2021 về Công tác công an phòng ngừa đấu tranh ngăn chặn âm mưu, hoạt động lợi dụng tổ chức người lao động xâm phạm ANQG-TTATXH",
    noiDung: "Xây dựng báo cáo hàng tháng kết quả triển khai thực hiện Đề án",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA04",
    sanPham: "Báo cáo định kỳ hằng tháng",
    ngayHetHan: "2026-07-30",
    trangThai: ""
  },
  {
    id: "C9",
    stt: 9,
    canCu: "Kế hoạch số 318-KH/ĐUCA ngày 28/6/2025 của Đảng ủy Công an Trung ương và Kế hoạch số 397/KH-BCA-A04 ngày 28/6/2025 của Bộ Công an về phát triển kinh tế tư nhân",
    noiDung: "Chủ trì theo dõi, đôn đốc việc triển khai thực hiện Kế hoạch này.",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA04",
    sanPham: "Báo cáo định kỳ hằng tháng",
    ngayHetHan: "2026-07-28",
    trangThai: ""
  },
  {
    id: "C10",
    stt: 10,
    canCu: "Thông báo số 30/TB-CAT-PV01 ngày 27/5/2026 \"Thông báo ý kiến chỉ đạo của đồng chí Giám đốc Công an tỉnh",
    noiDung: "Tăng cường công tác quản lý người nước ngoài",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PV01, PA08",
    sanPham: "Lồng ghép thành một mục trong báo cáo tháng để tập hợp",
    ngayHetHan: "2026-07-25",
    trangThai: ""
  },
  {
    id: "C11",
    stt: 11,
    canCu: "Kế hoạch số 292/KH-CAT-PC06 ngày 28/5/2026 về việc triển khai “Chiến dịch mùa hè số cùng VNeID”",
    noiDung: "Thực hiện đảm bảo các yêu cầu, nội dung của kế hoạch (hoàn thành trước ngày 02/9/2026)",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC06",
    sanPham: "Thực hiện và báo cáo kết quả định kỳ hàng tháng trước ngày 30",
    ngayHetHan: "2026-07-30",
    trangThai: ""
  },
  {
    id: "C12",
    stt: 12,
    canCu: "Hướng dẫn số 714/HD-CAT-PC06 ngày 20/5/2026 của Công an tỉnh",
    noiDung: "Báo cáo phân loại địa bàn công cộng (hoàn thành trước ngày 10/12/2026)",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC06",
    sanPham: "Có báo cáo định kỳ năm",
    ngayHetHan: "2026-07-31",
    trangThai: ""
  },
  {
    id: "C13",
    stt: 13,
    canCu: "Công văn số 509/CAT-PC06 ngày 22/10/2025 về việc triển khai thực hiện Thông tư số 89/2025/TT-BCA ngày 18/9/2025 của Bộ trưởng Bộ Công an sửa đổi, bổ sung một số điều của Thông tư 24/2022/TT-BCA ngày 19/5/2022 quy định biểu mẫu công tác của CSKV và Thông tư 25/2022/TT-BCA ngày 19/5/2025 quy định về CSKV",
    noiDung: "Thực hiện các mặt công tác theo chức năng CSKV",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC06",
    sanPham: "Có báo cáo định kỳ hàng tháng, Quý, 6 tháng, năm",
    ngayHetHan: "2026-07-30",
    trangThai: ""
  },
  {
    id: "C14",
    stt: 14,
    canCu: "Công văn số 771/CAT-PC06 ngày 14/8/2025 về việc chấn chỉnh công tác quản lý, giáo dục đối tượng ở địa bàn cơ sở; Công văn số 1547/CAT-PC06 ngày 26/3/2026 về việc chấn chỉnh công tác rà soát, cập nhật thông tin đối tượng vào phần mềm quản lý",
    noiDung: "Thực hiện hiệu quả Chỉ thị về tăng cường các biện pháp nghiệp vụ và ứng dụng công nghệ thông tin trong công tác quản lý, giáo dục đối tượng ở địa bàn cơ sở đáp ứng yêu cầu trong tình hình mới",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC06",
    sanPham: "Cập nhật thông tin trên phần mềm\nCó báo cáo định kỳ 6 tháng, năm",
    ngayHetHan: "2026-07-25",
    trangThai: ""
  },
  {
    id: "C15",
    stt: 15,
    canCu: "Công văn số 3409/CAT-PC06 ngày 26/5/2026 về tăng cường thực hiện công tác nắm, giải quyết mâu thuẫn trong nội bộ Nhân dân",
    noiDung: "Thực hiện công tác nắm tình hình, tham gia giải quyết mâu thuẫn trong nội bộ Nhân dân",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC06",
    sanPham: "Cập nhật đầy đủ vụ việc trên phần mềm\nCó báo cáo định kỳ 6 tháng, năm",
    ngayHetHan: "2026-07-28",
    trangThai: ""
  },
  {
    id: "C16",
    stt: 16,
    canCu: "Kế hoạch số 292/KH-CAT-PC06 ngày 20/9/2023 về kiểm tra, phúc tra công tác CSKV",
    noiDung: "Thực hiện công tác kiểm tra, phúc tra của CSKV đảm bảo quy định hàng tháng",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC06",
    sanPham: "Cập nhật thông tin trên phần mềm quản lý trước ngày 10 hàng tháng",
    ngayHetHan: "2026-07-10",
    trangThai: ""
  },
  {
    id: "C17",
    stt: 17,
    canCu: "Kế hoạch số 38/KH-CAT-PC07 ngày 21/01/2026 của Công an tỉnh về việc triển khai công tác quản lý, vận hành, khai thác, sử dụng và tiếp tục cập nhật, hoàn thiện Cơ sở dữ liệu quốc gia về PCCC và CNCH, truyền tin báo cháy và ứng dụng \"Báo cháy 114\"",
    noiDung: "Hướng dẫn cơ sở thuộc diện quản lý về PCCC và CNCH trang bị, kết nối thiết bị truyền tin báo cháy",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC07",
    sanPham: "Có báo cáo kết quả định kỳ hằng tháng",
    ngayHetHan: "2026-07-25",
    trangThai: ""
  },
  {
    id: "C18",
    stt: 18,
    canCu: "Kế hoạch số 03/KH-CAT-PC07 ngày 07/01/2026 của Công an tỉnh",
    noiDung: "Nhân rộng tối thiểu 01 mô hình \"Tổ liên gia an toàn PCCC\" hoặc \"Điểm chữa cháy công cộng\" hoặc xây dựng mô hình PCCC tại cơ quan, doanh nghiệp, khu dân cư trên địa bàn quản lý.",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PC07",
    sanPham: "Có báo cáo kết quả định kỳ hằng tháng",
    ngayHetHan: "2026-07-20",
    trangThai: ""
  },
  {
    id: "C19",
    stt: 19,
    canCu: "Quyết định số 16-QĐ/UBKT, ngày 22/4/2026 của UBKT Đảng ủy Công an tỉnh về ban hành khung tiêu chí đánh giá, chấm điểm thi đua trên lĩnh vực công tác kiểm tra, giám sát, thi hành kỷ luật của Đảng trong Công an Lâm Đồng năm 2026",
    noiDung: "Báo cáo định kỳ tháng 7 công tác kiểm tra, giám sát, thi hành kỷ luật đảng (hoàn thành trước ngày 12/7/2026)",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX06",
    sanPham: "Báo cáo định kỳ tháng 7 công tác kiểm tra, giám sát, thi hành kỷ luật đảng",
    ngayHetHan: "2026-07-12",
    trangThai: ""
  },
  {
    id: "C20",
    stt: 20,
    canCu: "Kế hoạch số 45-KH/ĐUCA",
    noiDung: "Báo cáo công tác dư luận xã hội",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX03 (Đội 1)",
    sanPham: "Báo cáo tháng, quý, 06 tháng, năm",
    ngayHetHan: "2026-07-25",
    trangThai: ""
  },
  {
    id: "C21",
    stt: 21,
    canCu: "Hướng dẫn số 421/CAT-PX03",
    noiDung: "Báo cáo phân loại thi đua hằng tháng",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PX03 (Đội 2)",
    sanPham: "Báo cáo kết quả",
    ngayHetHan: "2026-07-28",
    trangThai: ""
  },
  {
    id: "C22",
    stt: 22,
    canCu: "Kế hoạch số 106/KH-CAT-PA02, ngày 27/8/2025 của Công an tỉnh",
    noiDung: "về phòng ngừa, đấu tranh, ngăn chặn hoạt động lợi dụng địa bàn Campuchia chống phá Việt Nam của các tổ chức phản động, FULRO lưu vong",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA02",
    sanPham: "Báo cáo định kỳ 06 tháng, 01 năm (trước 15/6 và 15/12).",
    ngayHetHan: "2026-07-15",
    trangThai: ""
  },
  {
    id: "C23",
    stt: 23,
    canCu: "Kế hoạch số 37/KH-CAT-PA02, ngày 16/3/2026 của Công an tỉnh",
    noiDung: "về đấu tranh CA Y524",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA02",
    sanPham: "Báo cáo trước ngày 15 hàng tháng",
    ngayHetHan: "2026-07-15",
    trangThai: ""
  },
  {
    id: "C24",
    stt: 24,
    canCu: "Kế hoạch số 172/KH-CAT-PA02, ngày 12/5/2026 của Công an tỉnh",
    noiDung: "về đấu tranh CA M125",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA02",
    sanPham: "Báo cáo trước ngày 15 hàng tháng",
    ngayHetHan: "2026-07-15",
    trangThai: ""
  },
  {
    id: "C25",
    stt: 25,
    canCu: "Kế hoạch số 147/KH-CAT-PA02, ngày 17/9/2026 của Công an tỉnh",
    noiDung: "về đấu tranh CA C525",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA02",
    sanPham: "Báo cáo trước ngày 15 hàng tháng.",
    ngayHetHan: "2026-07-15",
    trangThai: ""
  },
  {
    id: "C26",
    stt: 26,
    canCu: "Thực hiện Kế hoạch số 143/KH-CAT-PA02 ngày 23/4/2026 của Công an tỉnh về đảm bảo An ninh đối với Đại hội Đại biểu Phật giáo tỉnh Lâm Đồng nhiệm kỳ 2026-2031",
    noiDung: "Phòng PA02 chủ trì thực hiện kế hoạch. Công an các xã, phường, đặc khu, Đồn CA có nhiệm vụ phối hợp nắm tình hình liên quan trên địa bàn, định kỳ hàng tuần có báo cáo kết quả thực hiện",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA02",
    sanPham: "Báo cáo kết quả thứ Sáu hàng tuần cho đến khi kết thúc Đại hội",
    ngayHetHan: "2026-07-17",
    trangThai: ""
  },
  {
    id: "C27",
    stt: 27,
    canCu: "Kế hoạch số 41-KH/BCĐ ngày 02/02/2026 của Ban Chỉ đạo 35 Tỉnh ủy về “Hoạt động của Ban Chỉ đạo 35 Tỉnh ủy về bảo vệ nền tảng tư tưởng của Đảng, đấu tranh phản bác các quan điểm sai trái, thù địch năm 2026”",
    noiDung: "về “Hoạt động của Ban Chỉ đạo 35 Tỉnh ủy về bảo vệ nền tảng tư tưởng của Đảng, đấu tranh phản bác các quan điểm sai trái, thù địch năm 2026”",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Các báo cáo tuần, tháng, 06 tháng, 01 năm",
    ngayHetHan: "2026-07-31",
    trangThai: ""
  },
  {
    id: "C28",
    stt: 28,
    canCu: "Kế hoạch số 186/KH-CAT-PA03 ngày 15/5/2026",
    noiDung: "ĐTCB Chuyên đề “Phòng, chống địch phá hoại tư tưởng trên địa bàn tỉnh Lâm Đồng” năm 2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Báo cáo",
    ngayHetHan: "2026-07-30",
    trangThai: ""
  },
  {
    id: "C29",
    stt: 29,
    canCu: "Kế hoạch số 186/KH-CAT-PA03 ngày 15/5/2026",
    noiDung: "Kế hoạch điều tra cơ bản lĩnh vực bưu chính năm 2025 và những năm tiếp theo",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Báo cáo",
    ngayHetHan: "2026-07-30",
    trangThai: ""
  },
  {
    id: "C30",
    stt: 30,
    canCu: "Kế hoạch số 152/KH-CAT-PA03 ngày 19/9/2025 của Công an tỉnh Lâm Đồng",
    noiDung: "Điều tra cơ bản Lĩnh vực viễn thông và Lĩnh vực công nghệ thông tin",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Báo cáo",
    ngayHetHan: "2026-07-30",
    trangThai: ""
  },
  {
    id: "C31",
    stt: 31,
    canCu: "Kế hoạch số 41/KH-CAT-PA03, ngày 30/1/2026",
    noiDung: "Kế hoạch về đảm bảo an ninh, trật tự quá trình thực hiện chuyển đổi số quốc gia",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Kế hoạch",
    ngayHetHan: "2026-07-25",
    trangThai: ""
  },
  {
    id: "C32",
    stt: 32,
    canCu: "Kế hoạch số 238/KH-CAT-PA03 ngày 22/6/2026",
    noiDung: "Kế hoạch Điều tra cơ bản (ĐTCB) bổ sung “Lĩnh vực Thể dục thể thao năm 2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Kế hoạch",
    ngayHetHan: "2026-07-20",
    trangThai: ""
  },
  {
    id: "C33",
    stt: 33,
    canCu: "Kế hoạch số 188/KH-CAT-PA03 ngày 18/5/2026",
    noiDung: "Điều tra cơ bản bổ sung “Lĩnh vực báo chí trên địa bàn tỉnh Lâm Đồng” năm 2026",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Kế hoạch bổ sung",
    ngayHetHan: "2026-07-15",
    trangThai: ""
  },
  {
    id: "C34",
    stt: 34,
    canCu: "Kế hoạch số 189/KH-CAT-PA03 ngày 18/5/2026",
    noiDung: "Điều tra cơ bản bổ sung “Lĩnh vực xuất bản trên địa bàn tỉnh Lâm Đồng” năm 2026.",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Kế hoạch",
    ngayHetHan: "2026-07-15",
    trangThai: ""
  },
  {
    id: "C35",
    stt: 35,
    canCu: "Kế hoạch số 239/KH-CAT-PA03 ngày 22/6/2026",
    noiDung: "Điều tra cơ bản bổ sung “Chuyên đề văn nghệ sĩ có quan điểm sai trái trên địa bàn tỉnh Lâm Đồng” năm 2026.",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Tài liệu",
    ngayHetHan: "2026-07-28",
    trangThai: ""
  },
  {
    id: "C36",
    stt: 36,
    canCu: "Kế hoạch số 240/KH-CAT-PA03 ngày 22/6/2026",
    noiDung: "Điều tra cơ bản bổ sung “Lĩnh vực văn học nghệ thuật địa bàn tỉnh Lâm Đồng” năm 2026.",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Kế hoạch",
    ngayHetHan: "2026-07-28",
    trangThai: ""
  },
  {
    id: "C37",
    stt: 37,
    canCu: "Kế hoạch số 145/KH-CAT-PA03 ngày 17/9/2026",
    noiDung: "Công tác côngan vận động, tranh thủ văn nghệ sỹ, trí thức có uy tín phục vụ sự nghiệp bảo vệ an ninh quốc gia trong tình hình mới trên địa bàn tỉnh Lâm Đồng",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA03",
    sanPham: "Báo cáo",
    ngayHetHan: "2026-07-31",
    trangThai: ""
  },
  {
    id: "C38",
    stt: 38,
    canCu: "Kế hoạch số 16/KH-CAT-PA05 ngày 14/7/2025 của Công an tỉnh",
    noiDung: "Về công tác an ninh đối với hội nhóm trên không gian mạng liên quan đến an ninh quốc gia",
    thoiHan: "",
    diemGiao: 0.5,
    donVi: "PA05",
    sanPham: "Báo cáo",
    ngayHetHan: "2026-07-31",
    trangThai: ""
  }
];

export const SEED_D: TaskD[] = [
  { type: "header", title: "I. CHỈ TIÊU MỆNH LỆNH ĐẢNG ỦY CATW, BỘ CÔNG AN GIAO" },
  {
    type: "item",
    id: "D6",
    stt: "01",
    content: "- Bảo vệ tuyệt đối an ninh, an toàn Đại hội XIV của Đảng, bầu cử Quốc hội, Hội đồng nhân dân các cấp, các mục tiêu, công trình trọng điểm, các sự kiện chính trị, văn hóa, xã hội quan trọng của đất nước và các địa phương; hoạt động của lãnh đạo Đảng, Nhà nước, các đoàn khách quốc tế được tổ chức tại địa phương.\n- Không để hình thành, công khai hóa các nhen nhóm, tổ chức phản động trong nội địa.\n- Không để xảy ra khủng bố, phá hoại.\n- Kiểm soát không để phục hồi các nhen nhóm, tổ chức lợi dụng tôn giáo, tín ngưỡng hoạt động phức tạp về ANTT; không để hình thành, phát sinh các tổ chức tà đạo mới.\n- Không để xảy ra tập trung đông người, quy mô lớn, tính chất phức tạp (bao vây trụ sở, đập phá tài sản công, bắt giữ cán bộ nhằm gây áp lực với chính quyền; hoặc để các đối tượng phản động, chống đối, cực đoan lợi dụng kích động biểu tình, gây rối ANTT...), vượt quá khả năng giải quyết của các lực lượng cấp tỉnh, cần có sự chỉ đạo và tăng cường lực lượng của cấp Bộ.",
    yeuCau: "Không xét danh hiệu thi đua đối với Công an địa phương để xảy ra; hoặc không đạt yêu cầu một trong các trường hợp này",
    donVi: "PA02",
    trangThai: ""
  },
  {
    type: "item",
    id: "D7",
    stt: "02",
    content: "Kéo giảm số vụ phạm tội về trật tự xã hội",
    yeuCau: "Giảm 15% so với năm 2025\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC02)",
    donVi: "PC02",
    trangThai: ""
  },
  {
    type: "item",
    id: "D8",
    stt: "03",
    content: "Tham mưu giải quyết các vụ việc khiếu kiện phức tạp đang tồn tại trên địa bàn",
    yeuCau: "Thực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PA02.",
    donVi: "PA02",
    trangThai: ""
  },
  {
    type: "item",
    id: "D9",
    stt: "04",
    content: "Số vụ án, vụ việc tạm đình chỉ",
    yeuCau: "Giảm ít nhất 08% số lượng các vụ án và 08% số lượng các vụ việc tạm đình chỉ so với đầu kỳ năm 2026 \n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC01)",
    donVi: "PC01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D10",
    stt: "05",
    content: "Các vụ án, vụ việc oan sai, bỏ lọt tội phạm, bức cung, nhục hình trong hoạt động tố tụng hình sự.",
    yeuCau: "Không để xảy ra\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC01)",
    donVi: "PC01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D11",
    stt: "06",
    content: "Tỷ lệ tiếp nhận, thụ lý tố giác, tin báo về tội phạm, kiến nghị khởi tố",
    yeuCau: "100%\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC01)",
    donVi: "PC01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D12",
    stt: "07",
    content: "Tỷ lệ giải quyết tố giác, tin báo về tội phạm và kiến nghị khởi tố",
    yeuCau: "Đạt trên 93%\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC01)",
    donVi: "PC01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D13",
    stt: "08",
    content: "Tỷ lệ điều tra, khám phá án các loại tội phạm",
    yeuCau: "Đạt trên 85%\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC02)",
    donVi: "PC02",
    trangThai: ""
  },
  {
    type: "item",
    id: "D14",
    stt: "09",
    content: "Tỷ lệ điều tra khám phá các tội phạm rất nghiêm trọng, đặc biệt nghiêm trọng",
    yeuCau: "Đạt trên 95%\n (Thực hiện theo hướng dẫn, đánh giá tiến độ của PC02)",
    donVi: "PC02",
    trangThai: ""
  },
  {
    type: "item",
    id: "D15",
    stt: "10",
    content: "Tai nạn giao thông",
    yeuCau: "Kéo giảm 07% tai nạn giao thông trên cả 03 tiêu chí (về số vụ, số người chết và số người bị thương) so với năm 2025\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC08)",
    donVi: "PC08",
    trangThai: ""
  },
  {
    type: "item",
    id: "D16",
    stt: "11",
    content: "Tai nạn giao thông đặc biệt nghiêm trọng",
    yeuCau: "Không để xảy ra\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC08)",
    donVi: "PC08",
    trangThai: ""
  },
  {
    type: "item",
    id: "D17",
    stt: "12",
    content: "Tổng số vụ cháy cấp III, IV và cấp V",
    yeuCau: "Không để xảy ra số vụ cháy cấp III trở lên \n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC07)",
    donVi: "PC07",
    trangThai: ""
  },
  {
    type: "item",
    id: "D18",
    stt: "13",
    content: "Số vụ cháy cấp IV, V",
    yeuCau: "Không để xảy ra\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC07)",
    donVi: "PC07",
    trangThai: ""
  },
  {
    type: "item",
    id: "D19",
    stt: "14",
    content: "Người chấp hành xong án phạt tù thuộc diện tái hòa nhập cộng đồng tái phạm tội",
    yeuCau: "Dưới 1,35%/năm (nếu có)\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC10)",
    donVi: "PC10",
    trangThai: ""
  },
  {
    type: "item",
    id: "D20",
    stt: "15",
    content: "Số đối tượng truy nã trốn trong nước",
    yeuCau: "Kéo giảm 25% số đối tượng truy nã trong nước so với đầu kỳ năm 2026 (Tính từ 15/12/2025 - nếu có hoặc phát sinh); hạn chế tối đa phát sinh trốn truy nã trong năm 2026\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PC01)",
    donVi: "PC01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D21",
    stt: "16",
    content: "Phường, xã, đặc khu không ma túy",
    yeuCau: "Thực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PC04",
    donVi: "PC04",
    trangThai: ""
  },
  {
    type: "item",
    id: "D22",
    stt: "17",
    content: "Khởi công đầu tư xây dựng trụ sở Công an xã trên địa bàn (đối với các trụ sở có nhu cầu xây dựng mới, tương xứng với chức năng, nhiệm vụ, quy mô lực lượng Công an cơ sở)",
    yeuCau: "Phối hợp Phòng PH10 thực hiện chỉ tiêu bảo đảm hoàn thành chỉ tiêu của CA tỉnh",
    donVi: "PH10",
    trangThai: ""
  },
  { type: "header", title: "II. CHỈ TIÊU CÔNG TÁC CHUYÊN MÔN" },
  { type: "header", title: "1. Công tác tham mưu" },
  {
    type: "item",
    id: "D25",
    stt: 18,
    content: "- Tham mưu cấp ủy, chính quyền địa phương ban hành văn bản (Đề án, Nghị quyết, Kế hoạch...) về ANTT góp phần giải quyết các nhiệm vụ phát triển kinh tế những lĩnh vực trọng điểm nổi lên tại địa phương (liên quan các công trình giao thông, năng lượng, hoạt động gian lận thương mại, thị trường vàng, an ninh công nhân...)",
    yeuCau: "Tham mưu cấp ủy, chính quyền địa phương ban hành 03 văn bản (Đề án, Nghị quyết, Kế hoạch...)\n(Thực hiện theo hướng dẫn, đánh giá tiến độ của PA04)",
    donVi: "PA04",
    trangThai: ""
  },
  {
    type: "item",
    id: "D26",
    stt: 19,
    content: "Phấn đấu 100% các dự án trên địa bàn hiện đang có khó khăn, vướng mắc được CA tỉnh rà soát, tham mưu cấp ủy, chính quyền địa phương các giải pháp khắc phục, tháo gỡ",
    yeuCau: "Phối hợp triển khai thực hiện theo phân công và hướng dẫn của Phòng PA04 (phấn đấu 100%).",
    donVi: "PA04",
    trangThai: ""
  },
  {
    type: "item",
    id: "D27",
    stt: 20,
    content: "Số lượng tin, bài hằng tháng đăng trên Cổng/Trang thông tin điện tử của Công an tỉnh, thành phố trực thuộc Trung ương (tính cả tin/bài dẫn nguồn; không tính tin, bài trên các kênh mạng xã hội của Công an cấp tỉnh; trong đó yêu cầu số tin, bài cảnh báo tội phạm, cảnh báo an toàn tối thiểu đạt... tin/bài).\n* Từ ngày 15/11/2025-14/01/2026, thực hiện đồng đều 02 tin, bài/tháng (theo Công văn số 3097/CAT-PV01-Đ4 ngày 15/01/2026; trừ Phòng PX03 - 20 tin, bài/tháng), bắt đầu từ 15/01/2025 thực hiện và đánh giá kết quả theo Quyết định này.",
    yeuCau: "Mỗi tháng có ít nhất 04 tin, bài đối với CA phường; 03 tin, bài đối với CA xã bảo đảm chất lượng, được phê duyệt đăng trên Trang Thông tin điện tử Công an tỉnh và phục vụ việc lựa chọn đăng trên cổng TTĐT BCA",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D28",
    stt: 21,
    content: "Nâng cao hiệu quả công tác đối ngoại, hội nhập quốc tế song phương, đa phương trong các lĩnh vực công tác Công an, góp phần bảo đảm an ninh, trật tự.",
    yeuCau: "Công an các xã biên giới trên cơ sở chức năng, nhiệm vụ được giao, hàng Quý xây dựng ít nhất 01 báo cáo về kết quả hợp tác đối ngoại, hợp tác quốc tế góp phần bảo đảm ANTT tuyến biên giới trên địa bàn và gửi về Công an tỉnh (qua PV01) trước ngày 15 của tháng cuối Quý.\nCác địa phương còn lại phối hợp thực hiện đảm bảo các nhiệm vụ đề ra khi có yêu cầu.",
    donVi: "PV01",
    trangThai: ""
  },
  { type: "header", title: "2. Công tác bảo vệ an ninh quốc gia" },
  {
    type: "item",
    id: "D30",
    stt: 22,
    content: "Không để CQĐB nước ngoài lợi dụng xâm nhập nội bộ, cài cắm nội gián hoặc tội phạm lợi dụng để móc nối, thao túng, làm biến chất cán bộ",
    yeuCau: "Bảo đảm 100%",
    donVi: "PA01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D31",
    stt: 23,
    content: "Công tác tham mưu, phối hợp giải quyết các vụ, việc tranh chấp, khiếu kiện; đấu tranh chống phản động; bảo đảm an ninh các vùng chiến lược.",
    yeuCau: "- Bảo đảm an ninh nội địa, không để xảy ra các vụ, việc mâu thuẫn, xung đột gay gắt giữa người DTTS tại chỗ với các nông, lâm trường, doanh nghiệp và chính quyền địa phương, nhất là tranh chấp đất đai, hình thành \"điểm nóng\" về ANTT.\n- Giảm ít nhất 30% số đối tượng thành viên, cơ sở nội địa của phản động lưu vong, phản động mới có hoạt động phức tạp, thái độ lừng chừng.\n- Phối hợp đấu tranh giảm 100% số đối tượng phản động mới từ bỏ thường xuyên tán phát thông tin xấu độc (03 đối tượng).\n- Phòng, chống hoạt động phục hồi FULRO, \"Tin lành Đêga\", không để các đối tượng tập hợp lực lượng, hình thành khung tổ chức, phục hồi tổ chức cũ, công khai hóa tổ chức mới dưới bất kể hình thức, vỏ bọc, danh xưng nào ở trong nước.\n- Phối hợp PA02 tập trung kéo giảm ít nhất 60% địa bàn đã xác định đang bị ảnh hưởng, tác động của FULRO, \"Tin lành Đêga\".\n- Phòng ngừa, ngăn chặn, không để tái hoạt động \"Giê Sùa\", \"Bà Cô Dợ\".\n- Phối hợp PA02 kéo giảm số đối tượng cực đoan, chống đối trong DTTS đã phát hiện, xác minh, làm rõ xác định tại thời điểm tổng kết năm 2025 (PA02 sẽ phân bổ cụ thể chỉ tiêu).",
    donVi: "PA02",
    trangThai: ""
  },
  {
    type: "item",
    id: "D32",
    stt: 24,
    content: "Công tác bảo vệ bí mật nhà nước",
    yeuCau: "Không để xảy ra lộ, mất, thất lạc hồ sơ, tài liệu bí mật nhà nước trong CAND\n(Thực hiện theo hướng dẫn, đánh giá của PA03)",
    donVi: "PA03",
    trangThai: ""
  },
  {
    type: "item",
    id: "D33",
    stt: 25,
    content: "Trực tiếp phát hiện, kiến nghị xử lý bằng văn bản đối tượng, doanh nghiệp, dự án vi phạm quy định pháp luật trên lĩnh vực an ninh kinh tế",
    yeuCau: "Thực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PA04.",
    donVi: "PA04",
    trangThai: ""
  },
  {
    type: "item",
    id: "D34",
    stt: 26,
    content: "Phát hiện, tấn công, vô hiệu hóa đối tượng là nguồn phát tán, chia sẻ bài viết, video nội dung xấu độc, sai sự thật, bôi nhọ hình ảnh, uy tín của lãnh đạo Đảng, Nhà nước",
    yeuCau: "Thực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PA05.",
    donVi: "PA05",
    trangThai: ""
  },
  { type: "header", title: "3. Công tác đấu tranh phòng, chống tội phạm" },
  { type: "header", title: "3.1. Công tác điều tra, xử lý tội phạm" },
  {
    type: "item",
    id: "D37",
    stt: 27,
    content: "Điều tra, khám phá các vụ phạm tội về trật tự xã hội liên quan đến sử dụng công nghệ cao",
    yeuCau: "Thực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PC02",
    donVi: "PC02",
    trangThai: ""
  },
  { type: "header", title: "3.2. Công tác đấu tranh phòng, chống tội phạm về trật tự xã hội" },
  {
    type: "item",
    id: "D39",
    stt: 28,
    content: "Các băng nhóm tội phạm (theo Hướng dẫn số 06/HD-C02-P6) núp bóng doanh nghiệp, sử dụng công nghệ cao, lợi dụng không gian mạng để thực hiện tội phạm và các hành vi vi phạm pháp luật khác về trật tự xã hội",
    yeuCau: "Kiên quyết không để hình thành băng nhóm mới hoạt động trên địa bàn; không để đối tượng từng tham gia các băng nhóm tội phạm tại nước ngoài hoặc bị nước ngoài bắt giữ, xử lý, trục xuất về nước tiếp tục xuất cảnh tái hoạt động mà không nắm được thông tin.\n(Thực hiện theo hướng dẫn, đánh giá của PC02)",
    donVi: "PC02",
    trangThai: ""
  },
  {
    type: "item",
    id: "D40",
    stt: 29,
    content: "Băng nhóm tội phạm (theo Hướng dẫn số 06/HD-C02-P6)",
    yeuCau: "- Tổ chức đấu tranh triệt phá, làm tan rã toàn bộ các băng nhóm đã rà dựng trong thời gian không quá 6 tháng đối với băng nhóm đơn giản và nhóm chưa đủ tiêu chí; không quá 12 tháng đối với băng nhóm nguy hiểm; không quá 18 tháng với băng nhóm rất nguy hiểm (nếu có).\n- Không để băng, nhóm tội phạm tồn tại, hình thành mới hoạt động trên địa bàn và các đơn vị nghiệp vụ Bộ Công an, Công an tỉnh phát hiện, xử lý.\n(Thực hiện theo hướng dẫn, đánh giá của PC02)",
    donVi: "PC02",
    trangThai: ""
  },
  {
    type: "item",
    id: "D41",
    stt: 30,
    content: "Điểm, tụ điểm tệ nạn xã hội (mại dâm, cờ bạc)",
    yeuCau: "- 100% bị triệt phá, tan rã.\nKhông để tình trạng tồn tại kéo dài (từ 06 tháng trở lên) hoặc để Công an các đơn vị trực thuộc Bộ, Công an tỉnh, địa phương khác triệt phá.\n(Thực hiện theo hướng dẫn, đánh giá của PC02)",
    donVi: "PC02",
    trangThai: ""
  },
  { type: "header", title: "3.3. Công tác đấu tranh phòng, chống tội phạm về kinh tế, tham nhũng, buôn lậu, môi trường" },
  {
    type: "item",
    id: "D43",
    stt: 31,
    content: "Công tác điều tra, xử lý các vụ án về tham nhũng, kinh tế, môi trường (các tội danh thuộc Chương XVIII [không tính các tội danh tại mục 1], XIX, XXIII, Bộ Luật hình sự)",
    yeuCau: "- Phát hiện, xử lý vi phạm hành chính các hành vi vi phạm trên lĩnh vực trật tự quản lý kinh tế, môi trường (trực tiếp xử lý hành chính hoặc đề xuất cấp có thẩm quyền xử lý).\n- Trực tiếp, phối hợp các đơn vị nghiệp vụ CA tỉnh có kết quả thực hiện trong công tác điều tra, xử lý các vụ án về kinh tế, môi trường\nThực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PC03\n(cao hơn kết quả thực hiện năm 2025 từ 05% trở lên, đối với địa phương không có kết quả thực hiện thì phải có kết quả trong năm 2026)",
    donVi: "PC03",
    trangThai: ""
  },
  {
    type: "item",
    id: "D44",
    stt: 32,
    content: "Phát hiện, điều tra, xử lý hình sự đối với vi phạm pháp luật về ô nhiễm môi trường (Điều 235, 236, 239 Bộ Luật hình sự)",
    yeuCau: "Thực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PC03.",
    donVi: "PC03",
    trangThai: ""
  },
  {
    type: "item",
    id: "D45",
    stt: 33,
    content: "Phát hiện, điều tra, xử lý hình sự đối với vi phạm pháp luật về an toàn thực phẩm (Điều 193, 195, 317 Bộ Luật Hình sự)",
    yeuCau: "Thực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PC03.",
    donVi: "PC03",
    trangThai: ""
  },
  {
    type: "item",
    id: "D46",
    stt: 34,
    content: "Công tác đấu tranh phòng, chống tội phạm về buôn lậu, vận chuyển trái phép hàng hóa, tiền tệ qua biên giới, tiền giả, rửa tiền; hàng giả, gian lận thương mại theo tội danh thuộc Chương các tội xâm phạm trật tự quản lý kinh tế (mục 1, Chương XVIII, Bộ Luật hình sự).",
    yeuCau: "Thực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PC03.",
    donVi: "PC03",
    trangThai: ""
  },
  { type: "header", title: "3.4. Công tác đấu tranh phòng, chống tội phạm và vi phạm pháp luật về ma túy" },
  {
    type: "item",
    id: "D48",
    stt: 35,
    content: "- Quản lý người nghiện ma túy, người sử dụng trái phép chất ma túy, người quản lý sau cai nghiện ma túy;\n- Lập hồ sơ đưa đối tượng đi cơ sở cai nghiện bắt buộc.",
    yeuCau: "- 100% đối tượng được quản lý; kịp thời phát hiện, đấu tranh, xử lý các hành vi vi phạm pháp luật.\n- 100% đối tượng đủ điều kiện được lập hồ sơ đưa đi cai nghiện bắt buộc.\n(Thực hiện theo hướng dẫn, đánh giá của PC04)",
    donVi: "PC04",
    trangThai: ""
  },
  {
    type: "item",
    id: "D49",
    stt: 36,
    content: "Đấu tranh phòng, chống tội phạm, vi phạm pháp luật về ma túy (Riêng các vụ khởi tố tội mua bán trái phép chất ma túy chỉ được tính vào chỉ tiêu khi khởi tố được từ 02 đối tượng trở lên)",
    yeuCau: "Trực tiếp, phối hợp Phòng PC04 và các đơn vị nghiệp vụ CA tỉnh có kết quả đấu tranh phòng, chống tội phạm, vi phạm pháp luật về ma túy\nThực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PC04\n(cao hơn kết quả thực hiện năm 2025 từ 05% trở lên, đối với địa phương không có kết quả thực hiện thì phải có kết quả trong năm 2026)",
    donVi: "PC04",
    trangThai: ""
  },
  {
    type: "item",
    id: "D50",
    stt: 37,
    content: "Rà soát, triệt phá các điểm tổ chức, chứa chấp sử dụng trái phép chất ma túy",
    yeuCau: "100% được phát hiện, triệt xóa và không để phát sinh mới hoặc tái diễn tại các điểm đã triệt phá\n(Thực hiện theo hướng dẫn, đánh giá của PC04)",
    donVi: "PC04",
    trangThai: ""
  },
  { type: "header", title: "4. Công tác quản lý nhà nước" },
  {
    type: "item",
    id: "D52",
    stt: 38,
    content: "- Xe vi phạm “cơi nới” thành thùng hoạt động trên địa bàn quản lý.\n- Xe vi phạm tải trọng, quá khổ hoạt động phức tạp.",
    yeuCau: "- Không để xảy ra.\n- Không để xe vi phạm tải trọng, quá khổ hoạt động trên địa bàn hoạt động phức tạp để báo chí phản ánh và Bộ, Công an tỉnh kiểm tra ghi nhận có phương tiện vi phạm.\n(Thực hiện theo hướng dẫn, đánh giá của PC08)",
    donVi: "PC08",
    trangThai: ""
  },
  {
    type: "item",
    id: "D53",
    stt: 39,
    content: "Chỉ số cải cách hành chính (đạt loại xuất sắc, tốt, khá, hoàn thành nhiệm vụ)",
    yeuCau: "Tốt",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D54",
    stt: 40,
    content: "Phát triển khoa học, công nghệ, đổi mới sáng tạo và chuyển đổi số (Nghị quyết số 57 của Bộ Chính trị)",
    yeuCau: "Hoàn thành chỉ tiêu được giao trong năm 2026 theo Văn bản của Công an tỉnh",
    donVi: "PV01",
    trangThai: ""
  },
  { type: "header", title: "6. Công tác nghiệp vụ cơ bản của lực lượng An ninh nhân dân" },
  {
    type: "item",
    id: "D56",
    stt: 41,
    content: "Xây dựng mới LLBM thuộc Danh sách đầu mối chấm chọn đã được phê duyệt.",
    yeuCau: "Tỷ lệ đạt 100%.",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D57",
    stt: 42,
    content: "Số tin do LLBM cung cấp có giá trị và được đưa vào báo cáo Công an cấp xã, Đồn CA trở lên",
    yeuCau: "Tỷ lệ đạt 50%",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D58",
    stt: 43,
    content: "LLBM được chỉ đạo, định hướng thêm nhiệm vụ nắm tình hình, thực hiện yêu cầu nghiệp vụ của Cơ quan An ninh trên không gian mạng, đi sâu tiếp cận, nắm tình hình hoạt động của đối tượng QLNV, KTNV, VA hoặc nhóm kín có hoạt động phức tạp liên quan đến ANQG trên không gian mạng.",
    yeuCau: "Ít nhất 60% LLBM.",
    donVi: "PV01",
    trangThai: ""
  },
  { type: "header", title: "7. Công tác nghiệp vụ cơ bản của lực lượng Cảnh sát nhân dân\n(CA các đơn vị, địa phương thực hiện, đánh giá, báo cáo kết quả, tiến độ thực hiện theo Kế hoạch số 07/KH-CAT-PV01-TMCS ngày 07/01/2026 của CA tỉnh)" },
  {
    type: "item",
    id: "D60",
    stt: 44,
    content: "Tỷ lệ bắt, khởi tố đối tượng trong Sưu tra",
    yeuCau: "Đạt tối thiểu từ 50% trở lên",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D61",
    stt: 45,
    content: "Tỷ lệ hiềm nghi được xác lập từ công tác ĐTCB, sưu tra, CTVBM, vai ảo",
    yeuCau: "Chiếm từ 90% trở lên",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D62",
    stt: 46,
    content: "Tỷ lệ kết thúc hiềm nghi bằng hình thức xác lập chuyên án, chuyển khởi tố vụ án hoặc đủ căn cứ đề nghị khởi tố vụ án",
    yeuCau: "Từ 60% trở lên\n(Riêng hình sự, ma túy từ 80% trở lên)",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D63",
    stt: 47,
    content: "Tỷ lệ chuyên án trinh sát xác lập mới phát triển từ công tác NVCB (ĐTCB, sưu tra, hiềm nghi, CTVBM và vai ảo)",
    yeuCau: "Chiếm từ 90% trở lên \n(Chỉ tính chỉ tiêu đối với chuyên án trinh sát từ 02 đối tượng trở lên)",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D64",
    stt: 48,
    content: "Tỷ lệ đặc tình, CSBM xếp loại Khá trở lên trong tổng số đặc tình, CSBM đủ thời gian phân loại trong kỳ báo cáo",
    yeuCau: "Đạt từ 75% trở lên",
    donVi: "PV01",
    trangThai: ""
  },
  { type: "header", title: "8. Công tác xây dựng phong trào toàn dân bảo vệ ANTQ, xây dựng Công an phường kiểu mẫu, Công an xã" },
  {
    type: "item",
    id: "D66",
    stt: 49,
    content: "Không có địa bàn (cơ quan, doanh nghiệp, cơ sở giáo dục, khu dân cư, xã, phường, đặc khu) phân loại yếu",
    yeuCau: "Tham mưu, hướng dẫn khu dân cư, xã, phường, đặc khu, cơ quan, doanh nghiệp, cơ sở giáo dục theo phân cấp quản lý đăng ký và thực hiện đạt tiêu chuẩn “An toàn về an ninh, trật tự” theo Thông tư số 124/2021/TT-BCA, ngày 28/12/2021 của Bộ trưởng Bộ Công an và phân loại phong trào toàn dân bảo vệ ANTQ không có đơn vị xếp loại “Yếu”.\n(Thực hiện theo hướng dẫn, đánh giá của PV01)",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D67",
    stt: 50,
    content: "Xã, phường, đặc khu đạt tiêu chí điển hình về phong trào toàn dân bảo vệ ANTQ",
    yeuCau: "- Đối với các xã, phường, đặc khu năm 2025 được phân loại phong trào toàn dân bảo vệ ANTQ năm 2025 đạt loại “Khá” trở lên: Công an các xã, phường, đặc khu tham mưu UBND cấp xã đăng ký và thực hiện đạt tiêu chí điển hình về phong trào toàn dân bảo vệ ANTQ năm 2026.\n- Đối với các xã, phường năm 2025 phân loại phong trào toàn dân bảo vệ ANTQ đạt loại từ “Trung bình” trở xuống: Công an các xã, phường tham mưu UBND cấp xã thực hiện phong trào toàn dân bảo vệ ANTQ năm 2026 phải đạt loại “Khá” trở lên.\n(Thực hiện theo hướng dẫn, đánh giá của PV01)",
    donVi: "PV01",
    trangThai: ""
  },
  { type: "header", title: "9. Công tác xây dựng Đảng, xây dựng lực lượng" },
  { type: "header", title: "9.1. Công tác xây dựng Đảng, công tác chính trị, tổ chức cán bộ" },
  {
    type: "item",
    id: "D70",
    stt: 51,
    content: "- Không để xảy ra: (1) Tình trạng nội bộ mất đoàn kết; (2) Cán bộ, chiến sĩ sai phạm bị các cơ quan truyền thông, báo chí phản ánh gây dư luận xấu ảnh hưởng đến hình ảnh, uy tín của lực lượng Công an nhân dân",
    yeuCau: "Không để xảy ra",
    donVi: "PX01",
    trangThai: ""
  },
  { type: "header", title: "9.2. Công tác tổ chức cán bộ" },
  {
    type: "item",
    id: "D72",
    stt: 52,
    content: "Lãnh đạo cấp phòng hoặc tương đương, chỉ huy trở lên bị khởi tố hình sự.\nKhông để tập thể, cá nhân cán bộ, đảng viên sai phạm thuộc thẩm quyền xem xét, quyết định của Đảng ủy, Ban thường vụ Đảng ủy CATW, Ban thường vụ Đảng ủy CA tỉnh.",
    yeuCau: "Không để xảy ra",
    donVi: "PX01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D73",
    stt: 53,
    content: "Cán bộ, chiến sĩ sai phạm bị xử lý kỷ luật (không tính số Công an địa phương chủ động phát hiện).",
    yeuCau: "Dưới 0,4%",
    donVi: "PX01",
    trangThai: ""
  },
  { type: "header", title: "9.3. Công tác thanh tra, kiểm tra, giải quyết khiếu nại tố cáo" },
  {
    type: "item",
    id: "D75",
    stt: 54,
    content: "Tiếp nhận, xử lý đơn khiếu nại, tố cáo, kiến nghị phản ánh",
    yeuCau: "- 100% đơn khiếu nại, tố cáo, kiến nghị, phản ánh không thuộc thẩm quyền giải quyết được hướng dẫn hoặc chuyển đến các cơ quan chức năng có thẩm quyền để giải quyết.\n- Đạt từ 90% trở lên đơn khiếu nại, tố cáo, kiến nghị, phản ánh thuộc thẩm quyền giải quyết được tiếp nhận, xử lý đúng quy định",
    donVi: "PX05",
    trangThai: ""
  },
  { type: "header", title: "III. CÁC NHÓM CHỈ TIÊU LỚN GIAI ĐOẠN 2026 - 2030" },
  {
    type: "item",
    id: "D77",
    stt: 1,
    content: "Tổ chức triển khai các giải pháp xây dựng địa bàn cấp xã không ma túy, phấn đấu đến năm 2030, ít nhất 100% địa bàn cấp xã trên toàn tỉnh không ma túy.",
    yeuCau: "Thực hiện theo kết quả giao chỉ tiêu và hướng dẫn, đánh giá tiến độ của PC04\n(- Năm 2026: Có 55 địa bàn cấp xã đạt tiêu chí (Đạt 44%);\n- Năm 2027: Có 65 địa bàn cấp xã đạt tiêu chí (Đạt 52%);\n- Năm 2028: Có 85 địa bàn cấp xã đạt tiêu chí (Đạt 65%);\n- Năm 2029: Có 105 địa bàn cấp xã đạt tiêu chí (Đạt 84%);\n- Năm 2030: Có 124 địa bàn cấp xã đạt tiêu chí (Đạt 100%)",
    donVi: "PC04",
    trangThai: ""
  },
  {
    type: "item",
    id: "D78",
    stt: 2,
    content: "Hoàn thành đầu tư, xây dựng 100% trụ sở Công an cấp xã trên toàn quốc và tại địa phương",
    yeuCau: "Phối hợp Phòng PH10 thực hiện đảm bảo hoàn thành chỉ tiêu của toàn tỉnh",
    donVi: "PH10",
    trangThai: ""
  },
  {
    type: "item",
    id: "D79",
    stt: 3,
    content: "Giải quyết dịch vụ công trên môi trường mạng",
    yeuCau: "Đạt tỷ lệ theo chỉ tiêu được giao của năm",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D80",
    stt: 4,
    content: "Phấn đấu tỷ lệ cắt giảm thủ tục hành chính nội bộ của Công an địa phương",
    yeuCau: "- Năm 2026: Đạt 20% trên tổng số thủ tục hành chính nội bộ;\n- Năm 2027: Đạt 30%;\n- Năm 2028: Đạt 40%;\n- Năm 2029: Đạt 50%;\n- Năm 2030: Đạt 50%.",
    donVi: "PV01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D81",
    stt: 5,
    content: "Phát hiện, tham mưu giải quyết căn cơ, hiệu quả các vụ việc khiếu kiện phức tạp trên địa bàn (chỉ tiêu thực hiện hằng năm, xuyên suốt nhiệm kỳ)",
    yeuCau: "Phối hợp các đơn vị nghiệp vụ thuộc CA tỉnh và đơn vị liên quan thực hiện đảm bảo hoàn thành chỉ tiêu của toàn tỉnh",
    donVi: "PA02",
    trangThai: ""
  },
  {
    type: "item",
    id: "D82",
    stt: 6,
    content: "100% các cơ sở có nguy cơ cao về môi trường, vệ sinh an toàn thực phẩm qua rà soát được QLNV và tham mưu giải pháp đẩy lùi nguy cơ; 100% cơ sở, khu vực, địa điểm ô nhiễm nghiêm trọng về môi trường được chuyển hóa “xanh” (chỉ tiêu thực hiện hằng năm, xuyên suốt nhiệm kỳ)",
    yeuCau: "Phối hợp Phòng PC03 thực hiện đảm bảo hoàn thành chỉ tiêu của toàn tỉnh",
    donVi: "PC03",
    trangThai: ""
  },
  {
    type: "item",
    id: "D83",
    stt: 7,
    content: "Lãnh đạo, chỉ huy đủ năng lực, điều kiện làm việc theo yêu cầu, nhiệm vụ trong môi trường quốc tế",
    yeuCau: "Phối hợp PX01 thực hiện đảm bảo hoàn thành chỉ tiêu của Công an tỉnh đạt từ 20-30% trên tổng số quân số lãnh đạo, chỉ huy của Công an tỉnh",
    donVi: "PX01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D84",
    stt: 8,
    content: "Lãnh đạo chỉ huy, cán bộ, chiến sĩ đạt chuẩn khung năng lực số trong Công an nhân dân.",
    yeuCau: "Phối hợp PX01 thực hiện đảm bảo hoàn thành chỉ tiêu của Công an tỉnh đạt 100% lãnh đạo chỉ huy, 70% cán bộ, chiến sĩ",
    donVi: "PX01",
    trangThai: ""
  },
  {
    type: "item",
    id: "D85",
    stt: 9,
    content: "Cán bộ có trình độ đại học công an và trung cấp lý luận chính trị trở lên",
    yeuCau: "Phối hợp PX01 thực hiện đảm bảo hoàn thành chỉ tiêu của Công an tỉnh trên 80% tổng quân số của Công an tỉnh.",
    donVi: "PX01",
    trangThai: ""
  }
];
