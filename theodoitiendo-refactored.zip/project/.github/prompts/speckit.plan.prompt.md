---
agent: speckit.plan
---
