# Bàn giao ngữ cảnh — Dự án "Hệ thống Quản lý Tiến độ Chỉ đạo & Chỉ tiêu"

> Dán toàn bộ file này vào đầu phiên chat mới với Claude (kèm file zip project đính kèm) để tiếp tục công việc mà không cần lặp lại từ đầu.

## 1. Bối cảnh dự án

Ứng dụng web client-side (React + TypeScript + Vite + Tailwind) giúp một đơn vị Công an xã tại Việt Nam theo dõi, quản lý, báo cáo nhiệm vụ/chỉ đạo/chỉ tiêu công tác. Dữ liệu lưu trong IndexedDB của trình duyệt, không có backend trung tâm (tính đến thời điểm bàn giao).

**Bối cảnh triển khai thực tế đã xác nhận với người dùng:**
- 1 máy tính dùng chung tại trụ sở (không cần mạng LAN giữa nhiều máy).
- 1-3 người dùng (Công an cấp xã + Lãnh đạo).
- Dữ liệu nội bộ, không đưa lên cloud — mọi thứ chạy local.

## 2. Yêu cầu cải thiện toàn diện — đã thống nhất 5 ưu tiên theo thứ tự

Người dùng đã xếp hạng (kéo-thả) theo đúng thứ tự này:

1. ✅ **Refactor `App.tsx` + tách custom hooks** — ĐÃ XONG
2. ✅ **Viết test tự động (Vitest)** — ĐÃ XONG
3. ✅ **Chuyển state management sang Zustand** — ĐÃ XONG
4. ✅ **Tối ưu UI/UX (loading, error handling)** — ĐÃ XONG
5. 🟡 **Xây dựng backend đầy đủ (DB + API + Auth)** — **BACKEND ĐÃ CODE XONG VÀ CÓ TEST, NHƯNG FRONTEND CHƯA ĐƯỢC NỐI VÀO. Đây là việc còn lại duy nhất — xem mục 4.6.**

## 3. Thiết kế backend — ĐÃ CHỐT và ĐÃ CODE

Đã thảo luận và người dùng đồng ý kiến trúc sau cho ưu tiên #5:

- **Không dùng cloud.** Chạy hoàn toàn local trên 1 máy tại trụ sở.
- **Database: SQLite** (không phải PostgreSQL/MongoDB) — lý do: 1 file `.db` duy nhất, không cần cài đặt server DB riêng, backup = copy file, khớp với tư duy "sao lưu" mà `.bat` hiện tại đang dùng. Quy mô 1-3 người dùng, SQLite thoải mái đủ dùng.
- **API: Express** (đã có sẵn trong `dependencies` của `package.json`, dù chưa dùng tới ngoài `backup-server.js`).
- **Auth: JWT + bcrypt đơn giản.** 2 vai trò: Công an cấp xã / Lãnh đạo. Không cần OAuth/SSO.
- **Kiến trúc:** gộp backend + frontend chạy trên cùng 1 máy qua `localhost` (giống mô hình `npm run start` hiện tại, nhưng thay `backup-server.js` bằng 1 Express server phục vụ luôn cả API lẫn giao diện tĩnh).
- **IndexedDB không bỏ đi** — giữ làm cache cục bộ để app vẫn xem được dữ liệu nếu server tạm gián đoạn.
- **Di trú dữ liệu cũ:** dùng lại tính năng xuất Excel sẵn có (`ExcelIO.tsx`) — xuất dữ liệu hiện tại ra Excel, viết 1 script import một lần để nạp vào SQLite. Không cần công cụ di trú riêng.

## 4. Đã làm được gì (chi tiết kỹ thuật)

### 4.1. Refactor `App.tsx` (1.673 → 911 dòng, giảm ~45%)
Tách 4 custom hook:
- `src/hooks/useAppState.ts` — giờ là wrapper mỏng quanh Zustand store (xem 4.3).
- `src/hooks/useBackupReminder.ts` — banner nhắc backup Excel (dismiss/snooze).
- `src/hooks/useViewPreferences.ts` — chế độ xem (card/excel, list/kanban), sidebar, lưu localStorage.
- `src/hooks/useGlobalAddTaskForm.ts` — toàn bộ form modal "Thêm nhiệm vụ" (~25 state field), gồm logic tự nhận diện/gợi ý ký hiệu văn bản.
- Util dùng chung mới: `src/utils/dateHelpers.ts`.

**Bug đã phát hiện và sửa trong lúc refactor:** điều kiện hiện banner "nhắc sao lưu" ban đầu thiếu case `daysSinceBackup === null` (người CHƯA TỪNG backup lần nào sẽ không thấy banner nhắc) — đã sửa đúng logic gốc.

### 4.2. Test tự động (Vitest)
- Cấu hình: `vitest.config.ts`, môi trường `jsdom`, `@testing-library/react`, setup tại `src/test/setup.ts`.
- Script: `npm test` (chạy 1 lần), `npm run test:watch`.
- **84 test, tất cả pass**, phủ:
  - `src/utils/documentHelper.test.ts` (30 test) — logic gõ tắt, tự nhận diện loại văn bản/đơn vị/CAT, chuyển đổi ngày. Trước đây **0 test**.
  - `src/hooks/useAppState.test.ts` (13 test) — load/seed/restore, CRUD, quy tắc "định kỳ tự nhân bản sang Mục C", `saveError`.
  - `src/hooks/useGlobalAddTaskForm.test.ts` (10 test).
  - `src/hooks/useBackupReminder.test.ts` (5 test).
  - `src/hooks/useViewPreferences.test.ts` (5 test).
  - `src/components/ErrorBoundary.test.tsx` (2 test).
  - `src/utils/cancu.test.ts` (19 test, có sẵn từ trước, không đổi).

### 4.3. Zustand
- `src/store/appStore.ts` — store tập trung chứa toàn bộ `AppState` (A/B/C/D + meta) và mọi hành động CRUD, thay cho `useState` khổng lồ.
- Side-effect tự động lưu (debounce 300ms + gọi `backup-server.js` + toast) chạy qua `useAppStore.subscribe()`, **độc lập với vòng đời React** — không phụ thuộc component nào đang render.
- `useAppState.ts` chỉ là wrapper giữ nguyên API cũ → **không cần sửa gì ở `App.tsx`** khi chuyển đổi.
- **Phạm vi có chủ đích:** chỉ chuyển phần dữ liệu chính (`useAppState`) sang Zustand. 3 hook còn lại vẫn dùng `useState` nội bộ vì đã đủ nhỏ gọn, không có nhu cầu chia sẻ cross-component.
- **Việc CHƯA làm (có thể làm sau nếu muốn):** các component con (`Dashboard`, `MainB`, `MainC`...) vẫn nhận dữ liệu qua props từ `App.tsx`, chưa gọi thẳng `useAppStore`. Muốn bỏ hẳn prop-drilling thì cần sửa từng component.

### 4.4. UI/UX
- `src/components/ErrorBoundary.tsx` — bọc toàn app trong `main.tsx`, tránh màn hình trắng khi có lỗi render, trấn an dữ liệu vẫn an toàn trong IndexedDB, có nút tải lại + chi tiết lỗi kỹ thuật gấp gọn.
- `saveError` trong Zustand store — banner đỏ hiển thị khi lưu IndexedDB thất bại (trước đây lỗi này chỉ `console.error`, **người dùng không hề biết dữ liệu không được lưu** — đây là rủi ro dữ liệu nghiêm trọng nhất đã sửa).
- Màn hình loading có spinner động thay vì chỉ chữ tĩnh.

### 4.5. Phát hiện ngoài lề (chưa xử lý, nêu để biết)
- **Dự án chưa cài `@types/react`** — gần như toàn bộ TypeScript trong codebase đang được hiểu ngầm là `any` thay vì kiểm tra kiểu thật. Khớp với mục "Tăng cường Type Safety" trong yêu cầu gốc của người dùng nhưng KHÔNG nằm trong 5 mục đã xếp hạng. Cài `@types/react` sẽ làm lộ ra nhiều lỗi kiểu tiềm ẩn khắp dự án — cần một đợt riêng, cẩn thận, có test bảo vệ (đã có 84 test) trước khi làm.
- Import chết đã dọn: `formatDonViBanHanhDisplay` (không dùng ở đâu trong bản gốc).

### 4.6. Backend (ưu tiên #5) — ĐÃ CODE, ĐÃ TEST, CHƯA NỐI VÀO FRONTEND

**File mới:**
- `server/db.js` — SQLite (`better-sqlite3`). 2 bảng: `users` (auth) và `app_state` (lưu **toàn bộ AppState dưới dạng 1 blob JSON**, y hệt cấu trúc IndexedDB hiện tại — quyết định có chủ đích để giảm rủi ro, không redesign quan hệ (relational) vội với quy mô 1-3 người dùng).
- `server/auth.js` — bcrypt (băm mật khẩu) + JWT (`jsonwebtoken`). Secret JWT tự sinh (`crypto.randomBytes`) và lưu vào `data/jwt-secret.txt` ở lần chạy đầu, không hardcode.
- `server.js` (root) — Express server hợp nhất, export `createServer()` (dùng để test) và tự `listen()` khi chạy trực tiếp. Route:
  - `POST /api/auth/login` — đăng nhập, trả JWT.
  - `GET /api/auth/me` — thông tin user hiện tại (cần token).
  - `GET /api/state` / `PUT /api/state` — đọc/ghi toàn bộ AppState (cần token).
  - `GET /api/health` — không cần token.
  - Phục vụ tĩnh `dist/` (frontend đã build) cho mọi route khác.
- `scripts/setup-users.js` — CLI tạo tài khoản đăng nhập đầu tiên (hỏi tên đăng nhập/mật khẩu/vai trò qua terminal). Chạy: `npm run backend:create-user`.
- `scripts/migrate-from-backup.js` — di trú dữ liệu 1 lần. **Quan trọng:** dùng file `backups/latest_backup.json` (do tính năng backup tự động hiện có ghi ra) làm nguồn, KHÔNG parse Excel — vì đây chính xác là cấu trúc AppState gốc, không có rủi ro sai lệch định dạng. Chạy: `npm run backend:migrate`.
- `server/test-env.js` — helper cho test, trỏ DB/JWT-secret sang thư mục tạm để test không đụng dữ liệu thật.

**Test đã viết (34 test mới, tổng cộng giờ là 109 test):**
- `server/db.test.js` (8 test) — users, app_state, ràng buộc UNIQUE/CHECK, round-trip lưu/đọc.
- `server/auth.test.js` (8 test) — hash mật khẩu, JWT sign/verify, middleware xác thực.
- `server.test.js` (9 test, dùng `supertest`) — test tích hợp qua HTTP thật: login, route được bảo vệ, PUT/GET state round-trip.
- Đã tự tay chạy thử server thật (không chỉ test tự động): build frontend, khởi động `server.js`, tạo user, login qua `curl`, GET/PUT `/api/state` — toàn bộ luồng hoạt động đúng.

**2 bug có sẵn từ trước đã phát hiện và sửa (không liên quan trực tiếp đến việc code backend mới, nhưng liên quan tới cùng khu vực code):**
1. `backup-server.js` **không chạy được** — dùng cú pháp CommonJS (`require`) trong khi `package.json` khai `"type": "module"` → lỗi `ReferenceError: require is not defined`. Đã đổi tên thành `backup-server.cjs` (không đổi logic bên trong) và cập nhật script `backup:server` trong `package.json`.
2. Script `"clean": "rm -rf dist server.js"` trong `package.json` — coi `server.js` là file build tự sinh (có thể còn sót từ cấu hình cũ nào đó). **Nguy hiểm** vì giờ `server.js` là source code thật. Đã sửa thành `"clean": "rm -rf dist"`.

**Script mới trong `package.json`:**
```json
"backend": "node server.js",
"backend:create-user": "node scripts/setup-users.js",
"backend:migrate": "node scripts/migrate-from-backup.js"
```

**`.gitignore`** đã thêm `data/` (chứa file `.db` + JWT secret) và `backups/`.

#### VIỆC CÒN LẠI DUY NHẤT: nối frontend vào backend

Hiện tại `src/store/appStore.ts` (Zustand) vẫn đọc/ghi thẳng IndexedDB (`src/db.ts`), **chưa gọi API mới**. Đây là bước cuối cùng để hoàn thành ưu tiên #5. Gợi ý cách làm an toàn (không phá vỡ trải nghiệm hiện tại):

1. Thêm 1 biến cấu hình (ví dụ `VITE_API_URL` hoặc phát hiện `window.location`) để biết đang chạy qua server mới (`node server.js`, phục vụ ở cùng origin) hay chạy kiểu cũ (`npm run dev` / `npm start`, chỉ IndexedDB).
2. Trong `useAppStore` (`src/store/appStore.ts`), thêm 1 cơ chế: nếu phát hiện có backend (ví dụ gọi `GET /api/health` thành công), ưu tiên gọi API cho `load()` và cho save (debounced hiện tại) thay vì/song song với IndexedDB. Cân nhắc giữ IndexedDB làm cache cục bộ (đã ghi trong quyết định kiến trúc ban đầu ở mục 3).
3. Cần đăng nhập trước khi dùng app khi chạy qua backend — thêm 1 màn hình đăng nhập đơn giản (form username/password gọi `POST /api/auth/login`, lưu token — **không dùng `localStorage` cho token nếu muốn an toàn hơn, nhưng với quy mô 1-3 người dùng nội bộ, `localStorage` chấp nhận được**).
4. Viết thêm test cho phần nối API này (theo đúng pattern đã dùng xuyên suốt: mock `fetch`, test hành vi, chạy `npm test` sau mỗi bước).
5. Cập nhật `README`/hướng dẫn sử dụng: quy trình mới sẽ là `npm run build` → `npm run backend:create-user` (lần đầu) → `npm run backend`, thay vì `npm start` (cách cũ vẫn giữ nguyên hoạt động song song, chưa xoá, để không phá vỡ người dùng chưa sẵn sàng chuyển).



## 5. Cách xác minh mọi thứ vẫn ổn (chạy sau MỖI thay đổi)

```bash
npm install       # nếu chưa có node_modules
npm test          # 109 test phải pass (75 frontend + 34 backend)
npx tsc --noEmit  # phải sạch, không lỗi
npm run build     # phải build thành công (build frontend, cần trước khi chạy `npm run backend`)
```

Test thử backend thật (không chỉ test tự động), ví dụ:
```bash
npm run build
npm run backend:create-user   # tạo tài khoản đầu tiên, trả lời 3 câu hỏi trên terminal
npm run backend                # chạy tại http://localhost:3002
# ở terminal khác:
curl -X POST http://localhost:3002/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"...","password":"..."}'
```

Lưu ý registry npm: nếu gặp lỗi không resolve được package, dùng:
```bash
npm install --registry https://registry.npmjs.org/
```
(registry mặc định của môi trường có thể trỏ tới mirror bị chặn mạng).

## 6. Việc tiếp theo — CHỈ CÒN 1 VIỆC: nối frontend vào backend

Backend (DB + API + Auth) đã code xong, đã test, đã tự chạy thử end-to-end thành công (xem mục 4.6). Việc duy nhất còn lại để hoàn thành ưu tiên #5:

1. Thêm cách phát hiện/cấu hình để `src/store/appStore.ts` biết đang chạy qua backend mới (`node server.js`) hay kiểu cũ (chỉ IndexedDB, qua `npm run dev`/`npm start`) — ví dụ gọi thử `GET /api/health`.
2. Sửa `load()`/save (debounce hiện tại) trong `useAppStore` để gọi `GET /api/state` / `PUT /api/state` khi có backend, thay vì (hoặc kèm thêm, làm cache) IndexedDB.
3. Thêm màn hình đăng nhập đơn giản (gọi `POST /api/auth/login`, lưu token) — chỉ hiện khi chạy qua backend.
4. Viết test cho phần nối API này (mock `fetch`, theo đúng pattern đã dùng ở `useAppState.test.ts`).
5. Chạy `npm test` + `tsc` + `build` sau mỗi bước — đã có 109 test làm lưới an toàn, cứ sửa xong là chạy ngay để biết có vỡ gì không.
6. Cập nhật hướng dẫn sử dụng: quy trình mới là `npm run build` → `npm run backend:create-user` (lần đầu) → `npm run backend`. Cách cũ (`npm start`) vẫn giữ nguyên hoạt động song song, chưa xoá, để không phá vỡ người dùng chưa sẵn sàng chuyển.

## 7. File đính kèm

File zip project đầy đủ (đã bao gồm mọi thay đổi ở mục 4) nằm cùng tin nhắn này trên Claude.ai — hãy tải về và tải lên lại ở phiên chat mới cùng với file `HANDOFF.md` này.
